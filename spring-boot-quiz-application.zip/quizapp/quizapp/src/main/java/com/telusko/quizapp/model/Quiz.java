package com.telusko.quizapp.model;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import lombok.Data;

@Entity
@Data
public class Quiz 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String title;
	
	@ManyToMany
	private List<Question> questions;
	
	public Quiz(){
		
	}
	public Quiz(Integer id,String title,List questions)
	{
		this.id=id;
		this.title=title;
		this.questions=questions;
	}
	
	public void setid(Integer id)
	{
		this.id=id;
	}
	public void setTitle(String title)
	{
		this.title=title;
	}
	public void setQuestions(List<Question> questions) 
	{
		this.questions=questions;
	}
	
}
